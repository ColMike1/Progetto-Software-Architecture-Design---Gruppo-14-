package com.example.Command;


public interface Command {
    public void execute();
}


